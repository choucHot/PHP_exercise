<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Strings</title>
</head>
<body>
<?php # Script 1.6 - strings.php

// Create the variables:
$first_name = 'Haruki';
$last_name = 'Murakami';
$book = 'Kafka on the Shore';

// Print the values:
echo "<p>The book <em>$book</em> was written by $first_name $last_name.</p>";

?>
</body>
</html>