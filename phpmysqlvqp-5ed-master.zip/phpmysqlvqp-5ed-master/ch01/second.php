<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Using Echo</title>
</head>
<body>
	<!-- Script 1.3 - second.php -->
	<p>This is standard HTML.</p>
<?php
echo 'This was generated using PHP!';
?>
</body>
</html>