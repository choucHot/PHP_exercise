<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Using Echo</title>
</head>
<body>
<?php
echo 'Hello, <strong>world</strong>!';
?>
</body>
</html>