<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Using Echo</title>
</head>
<body>
<?php
echo 'This sentence is
printed over two lines.';
?>
</body>
</html>