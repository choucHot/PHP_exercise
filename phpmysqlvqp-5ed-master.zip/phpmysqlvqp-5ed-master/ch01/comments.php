<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Comments</title>
</head>
<body>
<?php

# Script 1.4 - comments.php
# Created April 23, 2017
# Created by Larry E. Ullman
# This script does nothing much.

echo '<p>This is a line of text.<br>This is another line of text.</p>';

/*
echo 'This line will not be executed.';
*/

echo "<p>Now I'm done.</p>"; // End of PHP code.

?>
</body>
</html>